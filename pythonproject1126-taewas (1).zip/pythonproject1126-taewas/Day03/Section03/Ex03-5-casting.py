'''
파일명 : Ex03-5-casting.py

Casting
    변수에 유형을 지정하려는 경우 캐스팅으로 가능.
'''
# 정수형 (숫자가 더해짐)
x = int(1)
print(x)
y = int(2.8)
print(y)
z =int("3")
print(z)
print(type(z))
print(x+z)

# 실수형
x = float(1)
print(x)
z = float("3")
print(z)

# 문자형 (서로 이어짐 문자형이여서)
x = str(1)
y = str(2)
print(x)
print(x+y)

# 아스키코드 변환
a = ord('A')
print(a)
b = chr(65)
print(b)
