'''
파일명 : Ex03-1-escape.py

이스케이프 문자
  \  줄바꿈
  \  탭
   \ 백스페이스

    \ 작은따옴표
    \ 큰따옴표
    \ 줄 바꿈, 커서 앞으로 이동
    \v ->줄 바꿈,

   \ 수직탭
'''
print('Hello \'World'')
print("Hello \"World"")
print('*\n**\n***')
print('이름\t\t연락처')
print('제시카\t02-124-5678')
