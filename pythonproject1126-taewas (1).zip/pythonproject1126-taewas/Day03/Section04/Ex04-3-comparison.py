'''
파일명 : Ex04-3-comparison.py

관계연산자
    ex0 >, >=, <, <=, ==, !=
    2개 항을 비교하여 그 결과를 논리(bool) 자료형으로 반환
'''
a = 15
print('{} > 10 : {}'.format(a, a > 10))
print('{} < 10 : {}'.format(a, a < 10))
print('{} >= 10 : {}'.format(a, a >= 10))
print('{} <= 10 : {}'.format(a, a <= 10))
print('{} == 10 : {}'.format(a, a == 10))
print('{} != 10 : {}'.format(a, a != 10))