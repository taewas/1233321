### 파이썬 아나콘다 셋팅
- 아나콘다 사이트 접속
  - https://www.anaconda.com/ 접속   
  - 구글 아나콘다 검색!
  - 다운로드 install 실행
  -  next -> next .. 설치
  - 아나콘다 설치시 경로 확인하기!!!
  - 가상환경이 편하다

- PyCharm 설치
  - https://www.jetbrains.com/ko-kr/pycharm/download/#section=windows 설치
  - 구글파일팡 



- Git 설치
  - https://git-scm.com/ 접속
  - 구글에서 Git 검색
  - Download for Windons

  (64-bit Git for Windows setup.)
  - next -> next .. 설치
  -
  윈도우 cmd 실행.
```
# git 버전 확인 
git --version

# 사용자 이름 등록
git config --global user.name "사용자"
```

- Githud 회원가입하기
  -https://github.com 접속 회원가입하기

- 수업자료 